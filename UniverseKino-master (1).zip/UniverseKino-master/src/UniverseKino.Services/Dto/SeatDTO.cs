﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniverseKino.Services.Dto
{
    public class SeatDTO
    {
        public decimal Cost { get; set; }

        public int Row { get; set; }

        public int Number { get; set; }
    }
}
