namespace UniverseKino.Services
{

    public class TokenResponseDTO
    {
        public string Token { get; set; }
    }
}