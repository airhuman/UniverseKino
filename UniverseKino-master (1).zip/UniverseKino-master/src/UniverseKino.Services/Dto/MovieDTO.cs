﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniverseKino.Services.Dto
{
    public class MovieDTO
    {
        public string Name { get; set; }

        public string Genre { get; set; }

        public int Duration { get; set; }
    }
}
