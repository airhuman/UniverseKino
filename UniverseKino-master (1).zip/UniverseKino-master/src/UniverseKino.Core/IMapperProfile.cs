﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniverseKino.Core
{
    public interface IMapperProfile
    {
    }
}
