using AutoMapper;

namespace UniverseKino.Core
{
    public abstract class MapperProfileConfig : Profile
    {
        public MapperProfileConfig()
        {
        }

    }
}