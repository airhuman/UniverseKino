﻿using System;
using System.Collections.Generic;
using System.Text;
using UniverseKino.Data.Entities;

namespace UniverseKino.Data.Interfaces
{
    public interface ISessionRepository : IGenericRepository<Session>
    {
    }
}
