namespace UniverseKino.WEB.Models
{
    public class TokenResponseView
    {
        public string Token { get; set; }
    }
}